﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GBtest1
{
    public class Cat : PetAnimal 
    {
        public Cat(string name, int age) : base(name, age)
        {

        }
    }
}
