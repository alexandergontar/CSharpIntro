﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GBtest1
{
    public class PackAnimal : Animal
    {
        public PackAnimal(string name, int age) : base(name, age)
        {

        }
    }
}
