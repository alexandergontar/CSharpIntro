﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GBtest1
{
    public class Camel : PackAnimal
    {
        public Camel(string name, int age) : base(name, age)
        {

        }
    }
}
